$(document).ready(function(){
    
    $(".main").mouseover(function(){
        $(this).children(".sub").stop().slideDown(200);
    });
    $(".main").mouseout(function(){
        $(this).children(".sub").stop().slideUp(200);
    });
    // .main에 마우스를 올리면
        // 그것의 자식(.sub)을 슬라이딩하면서 보여준다.
    // .main에서 마우스를 치우면
        // 그것의 자식(.sub)을 슬라이딩하면서 숨겨준다.
    
//    var len = $(".main").length;
//    for(i=0; i<len; i++){
//        var sublen = $(".main").eq(i).children(".sub").length;
//        if(sublen != 0){
//            $(".main").eq(i).children("a").append("<span class='caret'></span>");
//        }
//    }
    
    $(".main").each(function(){
        var sublen = $(this).children(".sub").length;
        if(sublen != 0){
            $(this).children("a").append("<span class='caret'></span>");
        }
    });
    
    // 1. for文을 쓰는 법
    // 먼저 반복을 위해서 .main의 개수를 센다.
    // 그 개수만큼 반복을 하게 되는데...
        // i번째 .main 안에 .sub의 개수를 세서.
        // 그 개수가 0이 아니라면(서브가 있다!)
            // 그것(.main)의 자식 a의 안쪽 마지막에
            // 내용을 삽입한다. (<span class='caret'></span>)
    
    // 2. each()를 쓰는 법
    // 각 .main에게 고하노니
        // 그것(.main)의 안에 .sub의 개수를 세서.
        // 그 개수가 0이 아니라면(서브가 있다!)
            // 그것(.main)의 자식 a의 안쪽 마지막에
            // 내용을 삽입한다. (<span class='caret'></span>)
    
    
    var hpos = $("header").offset().top;
    
    $(document).scroll(function(){
        var now = $(this).scrollTop();
        if(now > hpos){
            $("header").addClass("fix");
            $("#dummy").show();
        }else{
            $("header").removeClass("fix");
            $("#dummy").hide();
        }
    });
    
    // header의 위치(문서의 위쪽 끝으로부터 떨어진 거리)를 잰다.
    // 문서를 스크롤 할 때마다
        // 현재 얼마나 스크롤했는지 잰다.
        // 만약 스크롤한 값이 header의 위치보다 크면
        // (header가 화면의 위쪽 끝에 닿은 이후)
            // header를 fixed한다.
        // 아니라면
            // header를 static한다.
            
    
    
    
});






































